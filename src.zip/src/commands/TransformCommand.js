/**
 * @file TransformCommand.js
 * Command for applying transform states (position, rotation, scale) to one or
 * more bricks. Supports full undo/redo and collaboration operation export.
 */

import { Command } from './Command.js';

/**
 * @typedef {{ x: number, y: number, z: number }} Vec3
 * @typedef {{ position: Vec3, rotation: Vec3, scale: Vec3 }} TransformState
 */

/**
 * Applies afterStates on execute() and beforeStates on undo().
 * @extends Command
 */
export class TransformCommand extends Command {
  /**
   * @param {object} params
   * @param {Array<object>}               params.bricks        - Array of brick objects.
   * @param {function(object, TransformState): void} params.transformFn
   *   Called with (brick, state) to physically move/rotate/scale the brick.
   * @param {Map<string, TransformState>} params.beforeStates  - State before transform.
   * @param {Map<string, TransformState>} params.afterStates   - State after transform.
   * @param {string}                      [params.description]  - Human-readable label.
   */
  constructor({ bricks, transformFn, beforeStates, afterStates, description = 'Transform' }) {
    super();

    /** @type {Array<object>} */
    this.bricks = bricks;

    /** @type {function(object, TransformState): void} */
    this.transformFn = transformFn;

    /** @type {Map<string, TransformState>} */
    this.beforeStates = beforeStates;

    /** @type {Map<string, TransformState>} */
    this.afterStates = afterStates;

    /** @type {string} */
    this.description = description;
  }

  /**
   * Applies afterStates to each brick.
   * @returns {Promise<void>}
   */
  async execute() {
    for (const brick of this.bricks) {
      const state = this.afterStates.get(brick.id);
      if (state !== undefined) {
        this.transformFn(brick, state);
      }
    }
  }

  /**
   * Reverts each brick to its beforeState.
   * @returns {Promise<void>}
   */
  async undo() {
    for (const brick of this.bricks) {
      const state = this.beforeStates.get(brick.id);
      if (state !== undefined) {
        this.transformFn(brick, state);
      }
    }
  }

  /**
   * Builds a collaboration operation representing the forward transform.
   * @returns {{ type: string, payload: object }}
   */
  toOperation() {
    const entries = [];
    for (const [instanceId, matrix] of this.afterStates) {
      entries.push({ instanceId, matrix });
    }
    return {
      type: 'PART_TRANSFORMED',
      payload: { entries },
    };
  }

  /**
   * Builds a collaboration operation representing the undo transform.
   * @returns {{ type: string, payload: object }}
   */
  toUndoOperation() {
    const entries = [];
    for (const [instanceId, matrix] of this.beforeStates) {
      entries.push({ instanceId, matrix });
    }
    return {
      type: 'PART_TRANSFORMED',
      payload: { entries },
    };
  }
}
