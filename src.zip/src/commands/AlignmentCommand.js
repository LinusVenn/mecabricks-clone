/**
 * @file AlignmentCommand.js
 * Command for aligning one or more bricks to computed positions.
 * Supports full undo/redo and collaboration operation export.
 */

import { Command } from './Command.js';

/**
 * @typedef {{ x: number, y: number, z: number }} Vec3
 */

/**
 * Moves bricks to afterPositions on execute() and beforePositions on undo().
 * @extends Command
 */
export class AlignmentCommand extends Command {
  /**
   * @param {object} params
   * @param {Array<object>}          params.bricks          - Array of brick objects.
   * @param {Map<string, Vec3>}      params.beforePositions - Positions before alignment.
   * @param {Map<string, Vec3>}      params.afterPositions  - Positions after alignment.
   * @param {string}                 [params.description]   - Human-readable label.
   */
  constructor({ bricks, beforePositions, afterPositions, description = 'Align' }) {
    super();

    /** @type {Array<object>} */
    this.bricks = bricks;

    /** @type {Map<string, Vec3>} */
    this.beforePositions = beforePositions;

    /** @type {Map<string, Vec3>} */
    this.afterPositions = afterPositions;

    /** @type {string} */
    this.description = description;
  }

  /**
   * Moves each brick to its afterPosition.
   * @returns {Promise<void>}
   */
  async execute() {
    for (const brick of this.bricks) {
      const pos = this.afterPositions.get(brick.id);
      if (pos !== undefined) {
        brick.group.position.set(pos.x, pos.y, pos.z);
      }
    }
  }

  /**
   * Moves each brick back to its beforePosition.
   * @returns {Promise<void>}
   */
  async undo() {
    for (const brick of this.bricks) {
      const pos = this.beforePositions.get(brick.id);
      if (pos !== undefined) {
        brick.group.position.set(pos.x, pos.y, pos.z);
      }
    }
  }

  /**
   * Builds a collaboration operation for the forward alignment.
   * @returns {{ type: string, payload: object }}
   */
  toOperation() {
    const entries = [];
    for (const [instanceId, position] of this.afterPositions) {
      entries.push({ instanceId, position });
    }
    return {
      type: 'PARTS_ALIGNED',
      payload: { entries },
    };
  }

  /**
   * Builds a collaboration operation for the undo alignment.
   * @returns {{ type: string, payload: object }}
   */
  toUndoOperation() {
    const entries = [];
    for (const [instanceId, position] of this.beforePositions) {
      entries.push({ instanceId, position });
    }
    return {
      type: 'PARTS_ALIGNED',
      payload: { entries },
    };
  }
}
