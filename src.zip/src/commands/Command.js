// =====================================================================
// Command.js – Phase K.8 (Command-Pattern + History)
//
// Stellt die Basis-Infrastruktur für das Command-Pattern bereit:
//
//   Command       – Abstrakte Basisklasse (execute / undo / toOperation)
//   CommandHistory – Stapel mit execute/undo/redo + HistoryManager-Brücke
//                    + optionale Kollaboration via Phase J
//
// Design-Entscheidungen:
//   • CommandHistory legt KEINE eigenen Snapshots an; es delegiert an
//     den bestehenden HistoryManager (snapshot-basiert) für lokales
//     Undo/Redo.
//   • Für kollaboratives Undo wird statt dem Snapshot-Restore eine
//     Gegenoperation erzeugt und über CollaborationManager.sendOperation()
//     gesendet.
//   • execute() sendet nach erfolgreicher Ausführung automatisch die
//     passende Operation an den CollaborationManager (falls verbunden).
// =====================================================================


// ─────────────────────────────────────────────────────────────────────
// Abstrakte Basisklasse
// ─────────────────────────────────────────────────────────────────────

export class Command {

    /**
     * @param {string} description  – Lesbare Beschreibung für Debugging / Tooltips
     */
    constructor(description = 'Command') {
        this.description = description;
        this._timestamp  = Date.now();
    }

    /**
     * Führt die Operation aus.
     * Muss überschrieben werden.
     *
     * @returns {Promise<void>}
     */
    async execute() {
        throw new Error(`${this.constructor.name}.execute() is not implemented.`);
    }

    /**
     * Macht die Operation rückgängig.
     * Muss überschrieben werden.
     *
     * @returns {Promise<void>}
     */
    async undo() {
        throw new Error(`${this.constructor.name}.undo() is not implemented.`);
    }

    /**
     * Gibt eine Operation zurück, die für die Phase-J-Kollaboration gesendet
     * werden kann. Optional – standardmäßig wird null zurückgegeben (kein Sync).
     *
     * @returns {{ type: string, payload: object } | null}
     */
    toOperation() {
        return null;
    }

    /**
     * Gibt die Gegenoperation zurück, die bei einem kollaborativen Undo gesendet
     * werden soll. Optional.
     *
     * @returns {{ type: string, payload: object } | null}
     */
    toUndoOperation() {
        return null;
    }
}


// ─────────────────────────────────────────────────────────────────────
// CommandHistory
// ─────────────────────────────────────────────────────────────────────

export class CommandHistory {

    /**
     * @param {{
     *   historyManager?:      import('../history/HistoryManager.js').HistoryManager
     *   collaborationManager?: import('../collaboration/CollaborationManager.js').CollaborationManager
     *   maxSize?:             number
     * }} options
     */
    constructor({
        historyManager       = null,
        collaborationManager = null,
        maxSize              = 200,
    } = {}) {
        this._history  = historyManager;
        this._collab   = collaborationManager;
        this._maxSize  = maxSize;

        /** @type {Command[]} */
        this._undoStack = [];

        /** @type {Command[]} */
        this._redoStack = [];

        /** @type {Set<() => void>} */
        this._listeners = new Set();
    }


    // ─────────────────────────────────────────────────────────────────
    // Execution
    // ─────────────────────────────────────────────────────────────────

    /**
     * Führt einen Command aus, fügt ihn dem Undo-Stack hinzu und
     * sendet ihn optional über die Kollaboration.
     *
     * @param {Command} command
     * @returns {Promise<void>}
     */
    async execute(command) {
        if (!(command instanceof Command)) {
            throw new TypeError('CommandHistory.execute: expected a Command instance.');
        }

        await command.execute();

        // Redo-Stack leeren (neue Operation bricht den Redo-Pfad ab)
        this._redoStack = [];

        // Undo-Stack begrenzen
        if (this._undoStack.length >= this._maxSize) {
            this._undoStack.shift();
        }
        this._undoStack.push(command);

        // Snapshot für lokales Undo/Redo
        this._history?.saveState?.();

        // Kollaboration
        const op = command.toOperation?.();
        if (op && this._collab?.isCollaborating) {
            await this._collab.sendOperation(op.type, op.payload).catch(err => {
                console.warn('[CommandHistory] sendOperation failed:', err.message);
            });
        }

        this._notify();
    }


    // ─────────────────────────────────────────────────────────────────
    // Undo / Redo
    // ─────────────────────────────────────────────────────────────────

    /**
     * Macht den letzten Command rückgängig.
     *
     * Im kollaborativen Modus wird eine Gegenoperation gesendet anstatt
     * einen Snapshot wiederherzustellen (um fremde Änderungen zu erhalten).
     *
     * @returns {Promise<boolean>}
     */
    async undo() {
        if (!this._undoStack.length) return false;

        const command = this._undoStack.pop();

        // Kollaborativer Modus: Gegenoperation senden
        if (this._collab?.isCollaborating) {
            const undoOp = command.toUndoOperation?.();
            if (undoOp) {
                await this._collab.sendOperation(undoOp.type, undoOp.payload).catch(err => {
                    console.warn('[CommandHistory] undo sendOperation failed:', err.message);
                });
            }
        }

        // Lokaler Modus: Command-Undo + HistoryManager
        await command.undo();
        this._history?.undo?.();

        this._redoStack.push(command);
        this._notify();
        return true;
    }

    /**
     * Stellt den letzten rückgängig gemachten Command wieder her.
     *
     * @returns {Promise<boolean>}
     */
    async redo() {
        if (!this._redoStack.length) return false;

        const command = this._redoStack.pop();
        await command.execute();
        this._history?.redo?.();
        this._undoStack.push(command);
        this._notify();
        return true;
    }


    // ─────────────────────────────────────────────────────────────────
    // Abfragen
    // ─────────────────────────────────────────────────────────────────

    /** @returns {boolean} */
    get canUndo() { return this._undoStack.length > 0; }

    /** @returns {boolean} */
    get canRedo() { return this._redoStack.length > 0; }

    /** @returns {number} */
    get undoCount() { return this._undoStack.length; }

    /** @returns {string|null} – Beschreibung des nächsten Undo-Schritts */
    get nextUndoDescription() {
        return this._undoStack[this._undoStack.length - 1]?.description ?? null;
    }

    /** @returns {string|null} – Beschreibung des nächsten Redo-Schritts */
    get nextRedoDescription() {
        return this._redoStack[this._redoStack.length - 1]?.description ?? null;
    }


    // ─────────────────────────────────────────────────────────────────
    // Subscription
    // ─────────────────────────────────────────────────────────────────

    /**
     * @param {() => void} callback
     * @returns {() => void} Unsubscribe
     */
    subscribe(callback) {
        this._listeners.add(callback);
        return () => this._listeners.delete(callback);
    }

    _notify() {
        for (const cb of this._listeners) {
            try { cb(); } catch (e) { console.error('[CommandHistory] subscriber error:', e); }
        }
    }

    /** Leert beide Stacks (z. B. beim Laden eines neuen Projekts). */
    clear() {
        this._undoStack = [];
        this._redoStack = [];
        this._notify();
    }
}
