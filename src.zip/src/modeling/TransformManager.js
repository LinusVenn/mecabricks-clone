/**
 * @file TransformManager.js  (Phase K.1)
 * High-level API for translating, rotating, and scaling bricks via
 * TransformCommand. Every mutation is recorded in commandHistory and
 * snapshots the persistent state via historyManager.
 */

import { TransformCommand } from '../commands/TransformCommand.js';

/**
 * @typedef {{ x: number, y: number, z: number }} Vec3
 * @typedef {{ position: Vec3, rotation: Vec3, scale: Vec3 }} TransformState
 */

/**
 * Built-in transformFn used by every command created in this manager.
 * Writes position, rotation, and scale from `state` onto `brick.group`.
 *
 * @param {object}         brick - Brick whose group will be mutated.
 * @param {TransformState} state - The state to apply.
 * @returns {void}
 */
function applyStateToBrick(brick, state) {
  if (state.position !== undefined) {
    brick.group.position.set(state.position.x, state.position.y, state.position.z);
  }
  if (state.rotation !== undefined) {
    brick.group.rotation.set(state.rotation.x, state.rotation.y, state.rotation.z);
  }
  if (state.scale !== undefined) {
    brick.group.scale.set(state.scale.x, state.scale.y, state.scale.z);
  }
}

/**
 * Reads the current transform off a brick and returns a plain-object snapshot.
 *
 * @param {object} brick
 * @returns {TransformState}
 */
function snapshotBrick(brick) {
  return {
    position: {
      x: brick.group.position.x,
      y: brick.group.position.y,
      z: brick.group.position.z,
    },
    rotation: {
      x: brick.group.rotation.x,
      y: brick.group.rotation.y,
      z: brick.group.rotation.z,
    },
    scale: {
      x: brick.group.scale.x,
      y: brick.group.scale.y,
      z: brick.group.scale.z,
    },
  };
}

/**
 * Builds before/after Maps for a single brick and a partial after-state.
 *
 * @param {object}         brick       - The brick being transformed.
 * @param {TransformState} afterState  - The desired end state (may be partial).
 * @returns {{ beforeStates: Map<string, TransformState>, afterStates: Map<string, TransformState> }}
 */
function buildStateMaps(brick, afterState) {
  const before = snapshotBrick(brick);

  // Merge: keep before values for any key not supplied in afterState.
  const after = {
    position: afterState.position ?? { ...before.position },
    rotation: afterState.rotation ?? { ...before.rotation },
    scale:    afterState.scale    ?? { ...before.scale },
  };

  const beforeStates = new Map([[brick.id, before]]);
  const afterStates  = new Map([[brick.id, after]]);

  return { beforeStates, afterStates };
}

// ---------------------------------------------------------------------------

export class TransformManager {
  /**
   * @param {object} params
   * @param {object} params.library        - Brick library.
   * @param {object} params.commandHistory - CommandHistory instance.
   * @param {object} params.historyManager - Persistence history manager.
   */
  constructor({ library, commandHistory, historyManager }) {
    /** @type {object} */
    this.library = library;

    /** @type {object} */
    this.commandHistory = commandHistory;

    /** @type {object} */
    this.historyManager = historyManager;
  }

  // -------------------------------------------------------------------------
  // Private helpers
  // -------------------------------------------------------------------------

  /**
   * Asserts the brick has a valid group.
   * @param {object} brick
   * @throws {Error} if brick.group is null or undefined.
   */
  _assertGroup(brick) {
    if (brick.group === null || brick.group === undefined) {
      throw new Error(
        `TransformManager: brick "${brick.id}" has no group. ` +
        'Ensure the brick is fully initialised before calling transform methods.'
      );
    }
  }

  /**
   * Creates a TransformCommand, executes it via commandHistory, then saves a
   * persistent snapshot.
   *
   * @param {object}                 brick
   * @param {Map<string, TransformState>} beforeStates
   * @param {Map<string, TransformState>} afterStates
   * @param {string}                 description
   * @returns {Promise<TransformCommand>}
   */
  async _executeCommand(brick, beforeStates, afterStates, description) {
    const command = new TransformCommand({
      bricks: [brick],
      transformFn: applyStateToBrick,
      beforeStates,
      afterStates,
      description,
    });

    await this.commandHistory.execute(command);
    await this.historyManager.saveState();

    return command;
  }

  // -------------------------------------------------------------------------
  // Public API
  // -------------------------------------------------------------------------

  /**
   * Reads the current transform of a brick as a plain object.
   *
   * @param {object} brick
   * @returns {TransformState}
   */
  getTransform(brick) {
    this._assertGroup(brick);
    return snapshotBrick(brick);
  }

  /**
   * Sets the absolute position of a brick.
   *
   * @param {object} brick
   * @param {Vec3}   position
   * @returns {Promise<void>}
   */
  async setPosition(brick, position) {
    this._assertGroup(brick);
    const { beforeStates, afterStates } = buildStateMaps(brick, { position });
    await this._executeCommand(brick, beforeStates, afterStates, 'Set Position');
  }

  /**
   * Sets the absolute rotation (Euler, radians) of a brick.
   *
   * @param {object} brick
   * @param {Vec3}   rotation
   * @returns {Promise<void>}
   */
  async setRotation(brick, rotation) {
    this._assertGroup(brick);
    const { beforeStates, afterStates } = buildStateMaps(brick, { rotation });
    await this._executeCommand(brick, beforeStates, afterStates, 'Set Rotation');
  }

  /**
   * Sets the absolute scale of a brick.
   *
   * @param {object} brick
   * @param {Vec3}   scale
   * @returns {Promise<void>}
   */
  async setScale(brick, scale) {
    this._assertGroup(brick);
    const { beforeStates, afterStates } = buildStateMaps(brick, { scale });
    await this._executeCommand(brick, beforeStates, afterStates, 'Set Scale');
  }

  /**
   * Translates a brick by adding an offset to its current position.
   *
   * @param {object} brick
   * @param {Vec3}   offset
   * @returns {Promise<void>}
   */
  async translate(brick, offset) {
    this._assertGroup(brick);
    const current = snapshotBrick(brick);
    const position = {
      x: current.position.x + offset.x,
      y: current.position.y + offset.y,
      z: current.position.z + offset.z,
    };
    const { beforeStates, afterStates } = buildStateMaps(brick, { position });
    await this._executeCommand(brick, beforeStates, afterStates, 'Translate');
  }

  /**
   * Rotates a brick around a world axis by a delta angle (radians).
   *
   * @param {object}        brick
   * @param {'x'|'y'|'z'}  axis
   * @param {number}        angle  - Delta angle in radians.
   * @returns {Promise<void>}
   */
  async rotate(brick, axis, angle) {
    this._assertGroup(brick);

    if (axis !== 'x' && axis !== 'y' && axis !== 'z') {
      throw new Error(`TransformManager.rotate: invalid axis "${axis}". Must be 'x', 'y', or 'z'.`);
    }

    const current = snapshotBrick(brick);
    const rotation = { ...current.rotation };
    rotation[axis] = rotation[axis] + angle;

    const { beforeStates, afterStates } = buildStateMaps(brick, { rotation });
    await this._executeCommand(brick, beforeStates, afterStates, `Rotate ${axis.toUpperCase()}`);
  }

  /**
   * Resets a brick to the identity transform:
   * position {0,0,0}, rotation {0,0,0}, scale {1,1,1}.
   *
   * @param {object} brick
   * @returns {Promise<void>}
   */
  async resetTransform(brick) {
    this._assertGroup(brick);

    const beforeStates = new Map([[brick.id, snapshotBrick(brick)]]);
    const identity = {
      position: { x: 0, y: 0, z: 0 },
      rotation: { x: 0, y: 0, z: 0 },
      scale:    { x: 1, y: 1, z: 1 },
    };
    const afterStates = new Map([[brick.id, identity]]);

    await this._executeCommand(brick, beforeStates, afterStates, 'Reset Transform');
  }

  /**
   * Applies a partial transform object to a brick.
   * Only the keys present in `transform` are changed; others are preserved.
   *
   * @param {object}         brick
   * @param {Partial<TransformState>} transform
   * @returns {Promise<void>}
   */
  async applyTransform(brick, transform) {
    this._assertGroup(brick);
    const { beforeStates, afterStates } = buildStateMaps(brick, transform);
    await this._executeCommand(brick, beforeStates, afterStates, 'Apply Transform');
  }
}
