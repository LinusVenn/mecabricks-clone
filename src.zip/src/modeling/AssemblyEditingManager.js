// =====================================================================
// AssemblyEditingManager.js – Phase K.5 (Erweiterte Baugruppenbearbeitung)
//
// Ermöglicht das gezielte Bearbeiten einzelner Baugruppen:
//   • enterAssembly(assembly)  – Baugruppe isolieren und Bearbeitungsmodus starten
//   • exitAssembly()           – Bearbeitungsmodus beenden, Sichtbarkeit wiederherstellen
//   • isolateAssembly()        – Alle anderen Bauteile ausblenden
//   • showAll()                – Alle Bauteile einblenden
//   • lockAssembly()           – Baugruppe sperren (keine Transformationen)
//   • unlockAssembly()         – Sperre aufheben
//   • getActiveAssembly()      – Aktuelle Baugruppe abfragen
//
// Baut auf IsolationManager (src/selection/IsolationManager) auf.
// =====================================================================


export class AssemblyEditingManager {

    /**
     * @param {{
     *   isolationManager:  import('../selection/IsolationManager.js').IsolationManager
     *   library:           import('../objects/PartLibrary.js').PartLibrary
     *   groupManager:      import('../editor/GroupManager.js').GroupManager
     * }} options
     */
    constructor({ isolationManager, library, groupManager }) {
        if (!isolationManager) throw new Error('AssemblyEditingManager: isolationManager is required.');
        if (!library)          throw new Error('AssemblyEditingManager: library is required.');

        this._isolation    = isolationManager;
        this._lib          = library;
        this._groups       = groupManager ?? null;

        /** @type {{ id: string, name: string, brickIds: string[] } | null} */
        this._activeAssembly = null;

        /** @type {Set<string>} – IDs gesperrter Baugruppen */
        this._locked = new Set();

        /** @type {Set<(assembly: object|null) => void>} */
        this._listeners = new Set();
    }


    // ─────────────────────────────────────────────────────────────────
    // Bearbeitungsmodus
    // ─────────────────────────────────────────────────────────────────

    /**
     * Betritt den Bearbeitungsmodus für eine Baugruppe.
     * Alle anderen Bauteile werden ausgeblendet.
     *
     * @param {{ id: string, name: string, brickIds: string[] }} assembly
     * @returns {boolean}  – true wenn erfolgreich
     */
    enterAssembly(assembly) {
        if (!assembly?.id) throw new Error('AssemblyEditingManager.enterAssembly: invalid assembly.');

        if (this._activeAssembly) {
            this.exitAssembly();
        }

        const bricks = this._resolveBricks(assembly.brickIds ?? []);

        if (bricks.length === 0) {
            console.warn(`AssemblyEditingManager: assembly "${assembly.id}" has no resolvable bricks.`);
            return false;
        }

        const success = this._isolation.isolate(bricks);
        if (!success) return false;

        this._activeAssembly = { ...assembly };
        this._notify();
        return true;
    }

    /**
     * Beendet den Bearbeitungsmodus und stellt die ursprüngliche Sichtbarkeit wieder her.
     *
     * @returns {boolean}
     */
    exitAssembly() {
        if (!this._activeAssembly) return false;

        this._isolation.exitIsolation();
        this._activeAssembly = null;
        this._notify();
        return true;
    }


    // ─────────────────────────────────────────────────────────────────
    // Sichtbarkeit
    // ─────────────────────────────────────────────────────────────────

    /**
     * Isoliert eine Baugruppe ohne Bearbeitungsmodus zu starten.
     * (Nur visuelle Isolation, keine Lock-Logik.)
     *
     * @param {{ id: string, brickIds: string[] }} assembly
     * @returns {boolean}
     */
    isolateAssembly(assembly) {
        const bricks = this._resolveBricks(assembly?.brickIds ?? []);
        return this._isolation.isolate(bricks);
    }

    /**
     * Macht alle Bauteile wieder sichtbar.
     */
    showAll() {
        this._isolation.showAll();
    }


    // ─────────────────────────────────────────────────────────────────
    // Sperre
    // ─────────────────────────────────────────────────────────────────

    /**
     * Sperrt eine Baugruppe (Transformationen werden abgelehnt).
     * @param {{ id: string }} assembly
     */
    lockAssembly(assembly) {
        if (!assembly?.id) throw new Error('AssemblyEditingManager.lockAssembly: invalid assembly.');
        this._locked.add(assembly.id);
        this._notify();
    }

    /**
     * Hebt die Sperre einer Baugruppe auf.
     * @param {{ id: string }} assembly
     */
    unlockAssembly(assembly) {
        if (!assembly?.id) throw new Error('AssemblyEditingManager.unlockAssembly: invalid assembly.');
        this._locked.delete(assembly.id);
        this._notify();
    }

    /**
     * Gibt an, ob eine Baugruppe gesperrt ist.
     * @param {{ id: string }} assembly
     * @returns {boolean}
     */
    isLocked(assembly) {
        return this._locked.has(assembly?.id);
    }

    /**
     * Prüft, ob eine Transformation auf einem Bauteil erlaubt ist.
     * Wird vom TransformManager (K.1) abgefragt, bevor eine Transformation ausgeführt wird.
     *
     * @param {object} brick
     * @returns {boolean}
     */
    canTransform(brick) {
        if (!this._groups || !brick?.id) return true;

        const group = this._groups.getGroupByBrickId(brick.id);
        if (!group) return true;

        return !this._locked.has(group.id);
    }


    // ─────────────────────────────────────────────────────────────────
    // Abfragen
    // ─────────────────────────────────────────────────────────────────

    /**
     * Gibt die aktuell im Bearbeitungsmodus befindliche Baugruppe zurück.
     * @returns {{ id: string, name: string, brickIds: string[] } | null}
     */
    getActiveAssembly() {
        return this._activeAssembly ? { ...this._activeAssembly } : null;
    }

    /** @returns {boolean} */
    get isEditing() {
        return this._activeAssembly !== null;
    }

    /** @returns {string[]} – IDs aller gesperrten Baugruppen */
    get lockedAssemblyIds() {
        return [...this._locked];
    }


    // ─────────────────────────────────────────────────────────────────
    // Subscription
    // ─────────────────────────────────────────────────────────────────

    /**
     * @param {(assembly: object|null) => void} callback
     * @returns {() => void} Unsubscribe
     */
    subscribe(callback) {
        this._listeners.add(callback);
        return () => this._listeners.delete(callback);
    }


    // ─────────────────────────────────────────────────────────────────
    // Internal
    // ─────────────────────────────────────────────────────────────────

    _resolveBricks(brickIds) {
        return brickIds
            .map(id => this._lib.getById?.(id))
            .filter(Boolean);
    }

    _notify() {
        const assembly = this._activeAssembly;
        for (const cb of this._listeners) {
            try { cb(assembly); } catch (e) {
                console.error('[AssemblyEditingManager] subscriber error:', e);
            }
        }
    }
}
