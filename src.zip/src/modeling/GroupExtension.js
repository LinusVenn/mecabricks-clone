// =====================================================================
// GroupExtension.js – Phase K.4 (Erweiterte Gruppenverwaltung)
//
// Erweitert den bestehenden GroupManager (src/editor/GroupManager) um:
//   • mergeGroups(groups)               – mehrere Gruppen zusammenführen
//   • nestGroup(childId, parentId)      – Gruppen verschachteln
//   • getGroupTree()                    – verschachtelte Hierarchie ausgeben
//   • addToGroup / removeFromGroup      – mit Command-Tracking
//
// Alle Operationen erzeugen Commands für Undo/Redo + Kollaboration.
// =====================================================================

import {
    GroupCommand,
    UngroupCommand,
    MergeGroupsCommand,
} from '../commands/GroupCommand.js';


export class GroupExtension {

    /**
     * @param {{
     *   groupManager:    import('../editor/GroupManager.js').GroupManager
     *   commandHistory:  import('../commands/Command.js').CommandHistory
     *   library:         import('../objects/PartLibrary.js').PartLibrary
     * }} options
     */
    constructor({ groupManager, commandHistory, library }) {
        if (!groupManager)   throw new Error('GroupExtension: groupManager is required.');
        if (!commandHistory) throw new Error('GroupExtension: commandHistory is required.');

        this._gm  = groupManager;
        this._cmd = commandHistory;
        this._lib = library;
    }


    // ─────────────────────────────────────────────────────────────────
    // Durchgereichte Methoden (mit Command-Wrapping)
    // ─────────────────────────────────────────────────────────────────

    /**
     * Erstellt eine neue Gruppe aus einem Array von Bauteilen.
     *
     * @param {object[]} bricks
     * @param {string}   [name]
     * @returns {Promise<object>}  – neue Gruppe
     */
    async createGroup(bricks, name = 'Gruppe') {
        const cmd = new GroupCommand({
            bricks,
            groupName: name,
            createFn:  (b, n) => this._gm.createGroup(b, n),
            deleteFn:  (id)   => this._gm.deleteGroup(id),
            description: `Gruppe erstellen: ${name}`,
        });
        await this._cmd.execute(cmd);
        return cmd._group;
    }

    /**
     * Löst eine Gruppe auf.
     *
     * @param {string} groupId
     * @returns {Promise<string[]>}  – freigegebene BrickIds
     */
    async ungroup(groupId) {
        const group = this._gm.getGroup(groupId);
        if (!group) throw new Error(`GroupExtension.ungroup: group "${groupId}" not found.`);

        const cmd = new UngroupCommand({
            group,
            ungroupFn: (id) => this._gm.ungroup(id),
            createFn:  (bricks, name) => this._gm.createGroup(bricks, name),
            library:   this._lib,
            description: `Gruppe auflösen: ${group.name}`,
        });
        await this._cmd.execute(cmd);
        return group.brickIds ?? [];
    }


    // ─────────────────────────────────────────────────────────────────
    // Neue Methode: Gruppen zusammenführen
    // ─────────────────────────────────────────────────────────────────

    /**
     * Führt mehrere Gruppen in einer neuen Gruppe zusammen.
     * Die alten Gruppen werden dabei aufgelöst.
     *
     * @param {string[]} groupIds     – IDs der zusammenzuführenden Gruppen
     * @param {string}   [newName]    – Name der neuen Gruppe
     * @returns {Promise<object>}     – neu erstellte Gruppe
     */
    async mergeGroups(groupIds, newName = 'Zusammengeführte Gruppe') {
        if (!groupIds?.length) throw new Error('GroupExtension.mergeGroups: groupIds required.');

        const groups = groupIds.map(id => {
            const g = this._gm.getGroup(id);
            if (!g) throw new Error(`GroupExtension.mergeGroups: group "${id}" not found.`);
            return g;
        });

        const cmd = new MergeGroupsCommand({
            groups,
            newGroupName: newName,
            mergeFn: (originalGroups) => {
                // 1. Alle Brick-IDs einsammeln
                const allBrickIds = originalGroups.flatMap(g => g.brickIds ?? []);
                // 2. Alte Gruppen auflösen
                for (const g of originalGroups) this._gm.ungroup(g.id);
                // 3. Neue Gruppe erstellen
                const bricks = allBrickIds
                    .map(id => this._lib?.getById?.(id))
                    .filter(Boolean);
                return this._gm.createGroup(bricks, newName);
            },
            splitFn: (mergedId, originalGroups) => {
                // Zusammengeführte Gruppe auflösen
                this._gm.ungroup(mergedId);
                // Originalgruppen wiederherstellen
                for (const og of originalGroups) {
                    const bricks = (og.brickIds ?? [])
                        .map(id => this._lib?.getById?.(id))
                        .filter(Boolean);
                    if (bricks.length > 0) {
                        this._gm.createGroup(bricks, og.name);
                    }
                }
            },
            description: `${groups.length} Gruppen zusammenführen`,
        });

        await this._cmd.execute(cmd);
        return cmd._mergedGroup;
    }


    // ─────────────────────────────────────────────────────────────────
    // Neue Methode: Gruppen-Verschachtelung (konzeptionell)
    // ─────────────────────────────────────────────────────────────────

    /**
     * Markiert eine Gruppe als Untergruppe einer anderen.
     * Da der bestehende GroupManager keine echte Hierarchie kennt,
     * wird die Beziehung in den Gruppennamen kodiert: "Parent > Child".
     *
     * Für eine tiefere Verschachtelung kann dieser Mechanismus später
     * durch einen echten Hierarchie-Manager ersetzt werden.
     *
     * @param {string} childGroupId
     * @param {string} parentGroupId
     * @returns {Promise<void>}
     */
    async nestGroup(childGroupId, parentGroupId) {
        const child  = this._gm.getGroup(childGroupId);
        const parent = this._gm.getGroup(parentGroupId);

        if (!child)  throw new Error(`GroupExtension.nestGroup: child  "${childGroupId}"  not found.`);
        if (!parent) throw new Error(`GroupExtension.nestGroup: parent "${parentGroupId}" not found.`);

        const nestedName = `${parent.name} > ${child.name}`;
        this._gm.renameGroup(childGroupId, nestedName);
    }


    // ─────────────────────────────────────────────────────────────────
    // Neue Methode: Hierarchie-Baum ausgeben
    // ─────────────────────────────────────────────────────────────────

    /**
     * Gibt alle Gruppen mit ihrer übergeordneten Gruppe zurück.
     * Nutzt die Name-Kodierung "Parent > Child" zur Hierarchieerkennung.
     *
     * @returns {Array<{ id:string, name:string, parentName:string|null, brickIds:string[] }>}
     */
    getGroupTree() {
        return this._gm.getAllGroups().map(g => {
            const parts    = g.name.split(' > ');
            const name     = parts[parts.length - 1];
            const parentName = parts.length > 1 ? parts[parts.length - 2] : null;
            return { id: g.id, name, parentName, brickIds: g.brickIds ?? [] };
        });
    }


    // ─────────────────────────────────────────────────────────────────
    // Direkt-Delegation (ohne Command)
    // ─────────────────────────────────────────────────────────────────

    getGroup(id)              { return this._gm.getGroup(id); }
    getAllGroups()             { return this._gm.getAllGroups(); }
    getGroupByBrickId(id)     { return this._gm.getGroupByBrickId(id); }
    addBrickToGroup(gId, bId) { return this._gm.addBrickToGroup(gId, bId); }
    removeBrickFromGroup(gId, bId) { return this._gm.removeBrickFromGroup(gId, bId); }
    renameGroup(gId, name)    { return this._gm.renameGroup(gId, name); }
    isMemberOfGroup(bId)      { return this._gm.isMemberOfGroup(bId); }
}
