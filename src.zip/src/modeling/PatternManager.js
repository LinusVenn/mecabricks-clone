/**
 * @file PatternManager.js
 * Phase K.3 — Pattern-duplication operations (linear, circular, grid).
 */

import { PatternCommand } from '../commands/DuplicateCommand.js';

export class PatternManager {
  constructor({ library, commandHistory }) {
    this._library = library;
    this._history = commandHistory;
  }

  _newId() { return crypto.randomUUID(); }

  _brickType(brick) { return brick.type ?? brick.userData?.partId ?? 'unknown'; }

  _copyBrick(brick, offset, rotationOffset) {
    const srcRot = brick.rotation ?? { x: 0, y: 0, z: 0 };
    const rot = rotationOffset
      ? { x: (srcRot.x ?? 0) + (rotationOffset.x ?? 0), y: (srcRot.y ?? 0) + (rotationOffset.y ?? 0), z: (srcRot.z ?? 0) + (rotationOffset.z ?? 0) }
      : { x: srcRot.x ?? 0, y: srcRot.y ?? 0, z: srcRot.z ?? 0 };
    return {
      id:   this._newId(),
      type: this._brickType(brick),
      color: brick.color,
      position: {
        x: brick.group.position.x + offset.x,
        y: brick.group.position.y + (offset.y ?? 0),
        z: brick.group.position.z + offset.z,
      },
      rotation: rot,
    };
  }

  _centroid(objects) {
    if (!objects || objects.length === 0) return { x: 0, y: 0, z: 0 };
    let sx = 0, sy = 0, sz = 0;
    for (const o of objects) { sx += o.group.position.x; sy += o.group.position.y; sz += o.group.position.z; }
    const n = objects.length;
    return { x: sx / n, y: sy / n, z: sz / n };
  }

  _buildFns() {
    const library = this._library;
    return {
      removeFn(id)   { const b = library.getById?.(id); if (b) library.removeBrick(b); },
      addFn(data)    { library.addBrickFromData(data); },
    };
  }

  async createLinearPattern({ objects, axis = 'x', count, spacing }) {
    if (!objects?.length || count < 1 || spacing <= 0) return [];
    const createdBricks = [];
    for (const brick of objects) {
      for (let i = 1; i <= count; i++) {
        const offset = { x: 0, y: 0, z: 0 };
        offset[axis] = i * spacing;
        createdBricks.push(this._copyBrick(brick, offset));
      }
    }
    const { removeFn, addFn } = this._buildFns();
    const cmd = new PatternCommand({ createdBricks, removeFn, addFn, patternConfig: { type: 'linear', axis, count, spacing }, description: 'Lineares Muster erstellen' });
    await this._history.execute(cmd);
    return createdBricks;
  }

  async createCircularPattern({ objects, axis, count, angle }) {
    if (!objects?.length || count < 1) return [];
    const centroid = this._centroid(objects);
    const step = angle / count;
    const createdBricks = [];
    for (const brick of objects) {
      const px = brick.group.position.x, py = brick.group.position.y, pz = brick.group.position.z;
      for (let i = 1; i <= count; i++) {
        const theta = step * i, cos = Math.cos(theta), sin = Math.sin(theta);
        let newX = px, newY = py, newZ = pz, rotOffset;
        if (axis === 'y') {
          const dx = px - centroid.x, dz = pz - centroid.z;
          newX = centroid.x + dx * cos - dz * sin; newZ = centroid.z + dx * sin + dz * cos;
          rotOffset = { x: 0, y: theta, z: 0 };
        } else if (axis === 'x') {
          const dy = py - centroid.y, dz = pz - centroid.z;
          newY = centroid.y + dy * cos - dz * sin; newZ = centroid.z + dy * sin + dz * cos;
          rotOffset = { x: theta, y: 0, z: 0 };
        } else {
          const dx = px - centroid.x, dy = py - centroid.y;
          newX = centroid.x + dx * cos - dy * sin; newY = centroid.y + dx * sin + dy * cos;
          rotOffset = { x: 0, y: 0, z: theta };
        }
        createdBricks.push(this._copyBrick(brick, { x: newX - px, y: newY - py, z: newZ - pz }, rotOffset));
      }
    }
    const { removeFn, addFn } = this._buildFns();
    const cmd = new PatternCommand({ createdBricks, removeFn, addFn, patternConfig: { type: 'circular', axis, count, angle }, description: 'Kreisförmiges Muster erstellen' });
    await this._history.execute(cmd);
    return createdBricks;
  }

  async createGridPattern({ objects, countX, countY, spacingX, spacingY }) {
    if (!objects?.length || countX < 1 || countY < 1) return [];
    const createdBricks = [];
    for (const brick of objects) {
      for (let ix = 0; ix < countX; ix++) {
        for (let iy = 0; iy < countY; iy++) {
          if (ix === 0 && iy === 0) continue;
          createdBricks.push(this._copyBrick(brick, { x: ix * spacingX, y: iy * spacingY, z: 0 }));
        }
      }
    }
    const { removeFn, addFn } = this._buildFns();
    const cmd = new PatternCommand({ createdBricks, removeFn, addFn, patternConfig: { type: 'grid', countX, countY, spacingX, spacingY }, description: 'Rastermuster erstellen' });
    await this._history.execute(cmd);
    return createdBricks;
  }
}
