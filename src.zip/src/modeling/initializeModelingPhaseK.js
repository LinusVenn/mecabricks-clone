// =====================================================================
// initializeModelingPhaseK – Phase K (Erweiterte Modellierungsfunktionen)
//
// Factory-Funktion, die alle Phase-K-Manager instantiiert und verdrahtet.
// Gibt ein Objekt zurück, das alle Sub-Manager direkt exponiert.
//
// Verwendung (in main.js):
//
//   const phaseK = await initializeModelingPhaseK({
//       editor,
//       library,
//       groupManager,
//       assemblyManager,
//       connectionManager,
//       historyManager,
//       isolationManager,
//       precisionAlignmentManager,
//       precisionMeasurementManager,
//       modelValidator,
//       collaborationManager,   // optional – Phase J
//   });
//
//   // Bauteil numerisch verschieben:
//   await phaseK.transformManager.translate(brick, { x: 5 });
//
//   // Lineares Muster:
//   await phaseK.patternManager.createLinearPattern({ objects, axis: 'x', count: 5, spacing: 20 });
// =====================================================================

import { CommandHistory }        from '../commands/Command.js';
import { TransformManager }      from './TransformManager.js';
import { AlignmentManager }      from './AlignmentManager.js';
import { DuplicationManager }    from './DuplicationManager.js';
import { PatternManager }        from './PatternManager.js';
import { GroupExtension }        from './GroupExtension.js';
import { AssemblyEditingManager } from './AssemblyEditingManager.js';
import { MeasurementManager }    from './MeasurementManager.js';
import { ModelValidationManager } from './ModelValidationManager.js';


/**
 * @param {{
 *   editor:                       object
 *   library:                      import('../objects/PartLibrary.js').PartLibrary
 *   groupManager:                 import('../editor/GroupManager.js').GroupManager
 *   assemblyManager?:             object
 *   connectionManager?:           object
 *   historyManager:               import('../history/HistoryManager.js').HistoryManager
 *   isolationManager:             import('../selection/IsolationManager.js').IsolationManager
 *   precisionAlignmentManager:    import('../precision/AlignmentManager.js').AlignmentManager
 *   precisionMeasurementManager:  import('../precision/MeasurementManager.js').MeasurementManager
 *   modelValidator?:              object
 *   collaborationManager?:        import('../collaboration/CollaborationManager.js').CollaborationManager
 * }} options
 *
 * @returns {{
 *   commandHistory:         CommandHistory
 *   transformManager:       TransformManager
 *   alignmentManager:       AlignmentManager
 *   duplicationManager:     DuplicationManager
 *   patternManager:         PatternManager
 *   groupExtension:         GroupExtension
 *   assemblyEditingManager: AssemblyEditingManager
 *   measurementManager:     MeasurementManager
 *   modelValidationManager: ModelValidationManager
 * }}
 */
export function initializeModelingPhaseK({
    editor,
    library,
    groupManager,
    assemblyManager             = null,
    connectionManager           = null,
    historyManager,
    isolationManager,
    precisionAlignmentManager,
    precisionMeasurementManager,
    modelValidator              = null,
    collaborationManager        = null,
}) {
    // ── Pflichtparameter prüfen ─────────────────────────────────────
    if (!library)          throw new Error('initializeModelingPhaseK: library is required.');
    if (!historyManager)   throw new Error('initializeModelingPhaseK: historyManager is required.');
    if (!isolationManager) throw new Error('initializeModelingPhaseK: isolationManager is required.');
    if (!precisionAlignmentManager)
        throw new Error('initializeModelingPhaseK: precisionAlignmentManager is required.');
    if (!precisionMeasurementManager)
        throw new Error('initializeModelingPhaseK: precisionMeasurementManager is required.');

    // ── 1. Command-Infrastruktur ────────────────────────────────────
    const commandHistory = new CommandHistory({
        historyManager,
        collaborationManager,
    });

    // ── 2. K.1 – Präzise Transformationen ──────────────────────────
    const transformManager = new TransformManager({
        library,
        commandHistory,
        historyManager,
    });

    // ── 3. K.2 – Erweiterte Ausrichtung ────────────────────────────
    const alignmentManager = new AlignmentManager({
        precisionAlignmentManager,
        commandHistory,
        library,
    });

    // ── 4. K.3 – Duplizieren ───────────────────────────────────────
    const duplicationManager = new DuplicationManager({
        library,
        commandHistory,
    });

    // ── 5. K.3 – Muster ────────────────────────────────────────────
    const patternManager = new PatternManager({
        library,
        commandHistory,
    });

    // ── 6. K.4 – Erweiterte Gruppenverwaltung ──────────────────────
    const groupExtension = new GroupExtension({
        groupManager,
        commandHistory,
        library,
    });

    // ── 7. K.5 – Baugruppenbearbeitung ─────────────────────────────
    const assemblyEditingManager = new AssemblyEditingManager({
        isolationManager,
        library,
        groupManager,
    });

    // ── 8. K.6 – Messwerkzeuge ─────────────────────────────────────
    const measurementManager = new MeasurementManager({
        precisionMeasurementManager,
        library,
    });

    // ── 9. K.7 – Modellvalidierung ─────────────────────────────────
    const modelValidationManager = new ModelValidationManager({
        modelValidator:    modelValidator ?? _createNullValidator(),
        library,
        connectionManager,
        groupManager,
    });

    // ── 10. K.8 – OperationDispatcher mit AssemblyEditingManager verknüpfen
    //         (damit ASSEMBLY_LOCKED/UNLOCKED-Ops remote angewendet werden können)
    if (collaborationManager?._dispatcher) {
        collaborationManager._dispatcher._assemblyEditingManager = assemblyEditingManager;
    }

    // ── Messwerkzeuge bei Modelländerungen automatisch als veraltet markieren
    if (historyManager) {
        const _origOnChange = historyManager.onChange;
        historyManager.onChange = () => {
            _origOnChange?.();
            measurementManager.markStale();
        };
    }

    console.log('[Phase K] Modellierungswerkzeuge bereit.');

    return {
        commandHistory,
        transformManager,
        alignmentManager,
        duplicationManager,
        patternManager,
        groupExtension,
        assemblyEditingManager,
        measurementManager,
        modelValidationManager,
    };
}


// ─────────────────────────────────────────────────────────────────────
// Null-Validator-Fallback (falls kein ModelValidator übergeben wurde)
// ─────────────────────────────────────────────────────────────────────

function _createNullValidator() {
    return {
        validate: () => ({ findings: [], elapsed: 0 }),
    };
}
