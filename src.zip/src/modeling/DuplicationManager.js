/**
 * @file DuplicationManager.js  (Phase K.3)
 * High-level API for duplicating one or more bricks via DuplicateCommand.
 * Each duplication is pushed onto commandHistory for undo/redo support.
 */

import { DuplicateCommand } from '../commands/DuplicateCommand.js';

/**
 * @typedef {{ x: number, y: number, z: number }} Vec3
 * @typedef {object} BrickData
 * @property {string} id
 * @property {string} type
 * @property {string} color
 * @property {Vec3}   position
 * @property {Vec3}   rotation
 */

/** @type {Vec3} */
const DEFAULT_OFFSET = { x: 0, y: 2, z: 0 };

export class DuplicationManager {
  /**
   * @param {object} params
   * @param {object} params.library        - Brick library.
   * @param {object} params.commandHistory - CommandHistory instance.
   */
  constructor({ library, commandHistory }) {
    /** @type {object} */
    this.library = library;

    /** @type {object} */
    this.commandHistory = commandHistory;
  }

  // -------------------------------------------------------------------------
  // Private helpers
  // -------------------------------------------------------------------------

  /**
   * Generates a new universally unique identifier.
   * @returns {string}
   */
  _newId() {
    return crypto.randomUUID();
  }

  /**
   * Extracts serialisable brick data from a live brick object, assigning a
   * freshly generated id.
   *
   * @param {object} brick  - Source brick (has .group, .type, .color, .userData).
   * @returns {BrickData}
   */
  _brickToData(brick) {
    const pos = brick.group.position;
    const rot = brick.group.rotation;

    return {
      id: this._newId(),
      type: brick.type ?? brick.userData?.partId ?? 'unknown',
      color: brick.color,
      position: { x: pos.x, y: pos.y, z: pos.z },
      rotation: { x: rot.x, y: rot.y, z: rot.z },
    };
  }

  /**
   * Builds removeFn and addFn closures over the library.
   *
   * @returns {{ removeFn: function(string): void, addFn: function(BrickData): object }}
   */
  _buildLibraryFns() {
    const removeFn = (brickId) => {
      const brick = this.library.getById(brickId);
      if (brick !== null && brick !== undefined) {
        this.library.removeBrick(brick);
      }
    };

    const addFn = (brickData) => {
      return this.library.addBrickFromData(brickData);
    };

    return { removeFn, addFn };
  }

  /**
   * Applies a Vec3 offset to a BrickData position (mutates in place).
   *
   * @param {BrickData} data
   * @param {Vec3}      offset
   */
  _applyOffset(data, offset) {
    data.position.x += offset.x;
    data.position.y += offset.y;
    data.position.z += offset.z;
  }

  // -------------------------------------------------------------------------
  // Public API
  // -------------------------------------------------------------------------

  /**
   * Duplicates a single brick, offsetting its position.
   *
   * @param {object} brick
   * @param {object} [options]
   * @param {Vec3}   [options.offset]  - Position offset for the copy.
   * @returns {Promise<void>}
   */
  async duplicate(brick, options = {}) {
    const offset = options.offset ?? DEFAULT_OFFSET;
    const data = this._brickToData(brick);
    this._applyOffset(data, offset);

    const { removeFn, addFn } = this._buildLibraryFns();

    const command = new DuplicateCommand({
      createdBricks: [data],
      removeFn,
      addFn,
      description: `Duplicate "${data.type}"`,
    });

    await this.commandHistory.execute(command);
  }

  /**
   * Duplicates every brick in the given array, offsetting all copies.
   *
   * @param {object[]} bricks
   * @param {object}   [options]
   * @param {Vec3}     [options.offset]
   * @returns {Promise<void>}
   */
  async duplicateSelection(bricks, options = {}) {
    const offset = options.offset ?? DEFAULT_OFFSET;
    await this.duplicateWithOffset(bricks, offset);
  }

  /**
   * Duplicates every brick in the array with an explicit offset vector.
   *
   * @param {object[]} bricks
   * @param {Vec3}     offset
   * @returns {Promise<void>}
   */
  async duplicateWithOffset(bricks, offset) {
    if (!Array.isArray(bricks) || bricks.length === 0) {
      return;
    }

    const createdBricks = bricks.map((brick) => {
      const data = this._brickToData(brick);
      this._applyOffset(data, offset);
      return data;
    });

    const { removeFn, addFn } = this._buildLibraryFns();

    const command = new DuplicateCommand({
      createdBricks,
      removeFn,
      addFn,
      description: `Duplicate ${createdBricks.length} brick${createdBricks.length !== 1 ? 's' : ''}`,
    });

    await this.commandHistory.execute(command);
  }
}
