/**
 * @file AlignmentManager.js
 * Phase K.2 — High-level alignment operations that wrap AlignmentCommand.
 */

import { AlignmentCommand } from '../commands/AlignmentCommand.js';

export class AlignmentManager {
  constructor({ precisionAlignmentManager, commandHistory, library }) {
    this._pam = precisionAlignmentManager;
    this._history = commandHistory;
    this._library = library;
  }

  _snapshot(bricks) {
    const map = new Map();
    for (const brick of bricks) {
      const p = brick.group.position;
      map.set(brick.id, { x: p.x, y: p.y, z: p.z });
    }
    return map;
  }

  _mapToObj(map) {
    const obj = {};
    for (const [id, pos] of map) obj[id] = pos;
    return obj;
  }

  async alignAxis(bricks, axis, mode, referenceBrick) {
    if (!bricks || bricks.length === 0) return;
    const beforeMap = this._snapshot(bricks);
    let target;
    if (referenceBrick) {
      target = referenceBrick.group.position[axis];
    } else {
      let minVal = Infinity, maxVal = -Infinity;
      for (const b of bricks) {
        const v = b.group.position[axis];
        if (v < minVal) minVal = v;
        if (v > maxVal) maxVal = v;
      }
      target = mode === 'min' ? minVal : mode === 'max' ? maxVal : (minVal + maxVal) / 2;
    }
    for (const b of bricks) b.group.position[axis] = target;
    const afterMap = this._snapshot(bricks);
    const cmd = new AlignmentCommand({
      bricks,
      beforePositions: this._mapToObj(beforeMap),
      afterPositions: this._mapToObj(afterMap),
      description: `Align ${axis.toUpperCase()} ${mode}`,
    });
    await this._history.execute(cmd);
  }

  async alignLeft(bricks, ref)    { return this.alignAxis(bricks, 'x', 'min', ref); }
  async alignRight(bricks, ref)   { return this.alignAxis(bricks, 'x', 'max', ref); }
  async alignCenterX(bricks, ref) { return this.alignAxis(bricks, 'x', 'center', ref); }
  async alignBottom(bricks, ref)  { return this.alignAxis(bricks, 'y', 'min', ref); }
  async alignTop(bricks, ref)     { return this.alignAxis(bricks, 'y', 'max', ref); }
  async alignCenterY(bricks, ref) { return this.alignAxis(bricks, 'y', 'center', ref); }
  async alignFront(bricks, ref)   { return this.alignAxis(bricks, 'z', 'min', ref); }
  async alignBack(bricks, ref)    { return this.alignAxis(bricks, 'z', 'max', ref); }
  async alignCenterZ(bricks, ref) { return this.alignAxis(bricks, 'z', 'center', ref); }

  async alignConnectionPoints(brickA, connectionPointA, brickB, connectionPointB) {
    const beforeMap = this._snapshot([brickA]);
    const worldBx = brickB.group.position.x + connectionPointB.x;
    const worldBy = brickB.group.position.y + connectionPointB.y;
    const worldBz = brickB.group.position.z + connectionPointB.z;
    brickA.group.position.x = worldBx - connectionPointA.x;
    brickA.group.position.y = worldBy - connectionPointA.y;
    brickA.group.position.z = worldBz - connectionPointA.z;
    const afterMap = this._snapshot([brickA]);
    const cmd = new AlignmentCommand({
      bricks: [brickA],
      beforePositions: this._mapToObj(beforeMap),
      afterPositions: this._mapToObj(afterMap),
      description: 'Verbindungspunkte ausrichten',
    });
    await this._history.execute(cmd);
  }

  async distribute(bricks, axis, spacing) {
    if (!bricks || bricks.length < 2) return;
    const beforeMap = this._snapshot(bricks);
    const sorted = [...bricks].sort((a, b) => a.group.position[axis] - b.group.position[axis]);
    const start = sorted[0].group.position[axis];
    for (let i = 0; i < sorted.length; i++) sorted[i].group.position[axis] = start + i * spacing;
    const afterMap = this._snapshot(bricks);
    const cmd = new AlignmentCommand({
      bricks,
      beforePositions: this._mapToObj(beforeMap),
      afterPositions: this._mapToObj(afterMap),
      description: `Verteilen entlang ${axis.toUpperCase()}`,
    });
    await this._history.execute(cmd);
  }
}
